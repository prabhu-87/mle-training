
from setuptools import setup
setup(
    name = "py_package",
    version = "0.0.1",
    author = "Prabhu-87",
    author_email = "prabhu.muralidharan@tigeranalytics.com",
    description = "Median House Prediction",
    license = "MIT",
    package_dir={"": "src"},

)
